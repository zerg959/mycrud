

<?php $__env->startSection('content'); ?>
    <div class="bg-light p-5 rounded">
        <?php if(auth()->guard()->check()): ?>
        <h1><?php echo e(Auth::user()->username); ?>'s Dashboard</h1>
        <p class="lead">Only authenticated users can access this section.</p>
        <ul>
            <li class="lead">Username: <?php echo e(Auth::user()->username); ?></li>
            <li class="lead">Name: <?php echo e(Auth::user()->name); ?></li>
            <li class="lead">Email: <?php echo e(Auth::user()->email); ?></li>
        </ul>
        <?php endif; ?>

        <?php if(auth()->guard()->guest()): ?>
        <h1>Homepage</h1>
        <p class="lead">Your viewing the home page. Please login to view the restricted data.</p>
        <?php endif; ?>
    </div>
    <hr>
    <div>
    <?php echo $__env->make('auth.partials.copy', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>  
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app-master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Julia\mycodes\mycrud\resources\views/home/index.blade.php ENDPATH**/ ?>